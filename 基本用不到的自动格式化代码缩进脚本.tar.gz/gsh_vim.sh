vim $1 << end
gg=G
:wq
end